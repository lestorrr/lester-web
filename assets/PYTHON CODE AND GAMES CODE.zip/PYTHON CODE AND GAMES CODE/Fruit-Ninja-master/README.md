# Fruit-Ninja
A clone of the game Fruit Ninja using PyGame
To run this game install the individual python modules given in requirements.txt file using pip.

You can run this game using the following command on your command prompt or terminal, depending on the version of python installed.
1. python game.py
2. python3 game.py
3. py game.py

You only have to move your mouse cursor over the fruit to cut it.

The game uses basic physics and the fps of the game is set to 13 which makes it look like the game is continuous. In reality, it is moving pictures and hence the images of the fruits do not move along a continuous path but are displayed on discrete points for a short span of time. Hence the user might face the problem, wherein the fruit is not cut even if the cursor is placed on the image of the fruit. Currently the game only has two fruits to play with.
