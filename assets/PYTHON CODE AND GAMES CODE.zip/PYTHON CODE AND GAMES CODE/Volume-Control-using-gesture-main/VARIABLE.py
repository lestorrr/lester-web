x, y, z = "Orange", "Banana", "Cherry"
print(x)
print(y)
print(z)