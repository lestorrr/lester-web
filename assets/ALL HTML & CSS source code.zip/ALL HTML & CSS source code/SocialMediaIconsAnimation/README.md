## Social media icons animation
![Project thumbnail](./thumbnail.png)