## Button pulse animation
![Project thumbnail](./thumbnail.jpg)