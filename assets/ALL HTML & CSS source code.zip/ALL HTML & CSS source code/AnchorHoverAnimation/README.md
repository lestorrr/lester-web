## Anchor hover animation
![Project thumbnail](./thumbnail.png)