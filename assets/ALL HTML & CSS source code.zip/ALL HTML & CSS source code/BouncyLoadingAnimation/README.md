## Bouncy loading animation
![Project thumbnail](./thumbnail.png)