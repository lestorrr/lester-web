## Button border animation
![Project thumbnail](./thumbnail.jpg)