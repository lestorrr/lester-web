## Input field animation 2.1
![Project thumbnail](./thumbnail.png)