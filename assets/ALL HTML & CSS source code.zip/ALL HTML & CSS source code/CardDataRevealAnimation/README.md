## Card data reveal animation
![Project thumbnail](./thumbnail.png)