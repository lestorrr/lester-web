## 3D text & confetti animation
![Project thumbnail](./thumbnail.png)