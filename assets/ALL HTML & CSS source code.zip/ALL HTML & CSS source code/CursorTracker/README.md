## Custom cursor tracker in JavaScript
![Project thumbnail](./thumbnail.png)