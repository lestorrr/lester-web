## Loading spinning animation
![Project humbnail](./thumbnail.jpg)
