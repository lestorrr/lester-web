## Emoji animation
![Project thumbnail](./thumbnail.jpg)