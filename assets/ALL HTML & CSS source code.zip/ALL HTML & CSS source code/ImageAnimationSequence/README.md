## Image animation sequence
![Project thumbnail](./thumbnail.png)
