## Gradient border animation 2.0
![Project thumbnail](./thumbnail.jpg)