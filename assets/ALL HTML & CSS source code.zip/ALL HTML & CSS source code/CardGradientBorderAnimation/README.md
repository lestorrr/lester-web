## Card gradient border animation
![Project thumbnail](./thumbnail.jpg)