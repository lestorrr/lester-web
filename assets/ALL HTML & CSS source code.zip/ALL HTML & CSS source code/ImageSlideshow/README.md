## Image slideshow animation
![Project thumbnail](./thumbnail.png)