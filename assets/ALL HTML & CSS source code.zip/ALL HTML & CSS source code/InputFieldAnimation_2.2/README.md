## Input field animation 2.2
![Project thumbnail](./thumbnail.png)