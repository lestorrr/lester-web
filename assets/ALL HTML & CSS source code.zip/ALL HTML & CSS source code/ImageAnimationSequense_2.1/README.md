## Image animation sequence 2.1
![Project thumbnail](./thumbnail.png)