## Navbar link hover animation
![Project thumbnail](./thumbnail.png)