## Button interaction animation
![Project thumbnail](./thumbnail.png)