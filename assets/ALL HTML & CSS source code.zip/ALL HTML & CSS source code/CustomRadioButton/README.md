## Custom radio button animation
![Project thumbnail](./thumbnail.png)