## Basketball bounce animation
![Project thumbnail](./thumbnail.jpg)