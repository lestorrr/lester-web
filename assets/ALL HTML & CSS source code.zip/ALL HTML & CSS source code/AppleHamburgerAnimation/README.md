## Apple.com hamburger menu animation
![Project thumbnail](./thumbnail.jpg)