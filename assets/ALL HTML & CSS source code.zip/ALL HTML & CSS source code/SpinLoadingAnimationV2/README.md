## Spin loading animation V2
![Project thumbnail](./thumbnail.jpg)