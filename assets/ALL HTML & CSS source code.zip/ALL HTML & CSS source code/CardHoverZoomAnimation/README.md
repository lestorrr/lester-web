## Card image zoom-in animation
![Project thumbnail](./thumbnail.jpg)