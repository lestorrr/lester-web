## Bell notification animation V2
![Project thumbnail](./thumbnail.jpg)