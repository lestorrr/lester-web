## Sprite animation
![Project thumbnail](./thumbnail.png)