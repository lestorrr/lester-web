## Gradient background animation
![Project thumbnail](./thumbnail.jpg)