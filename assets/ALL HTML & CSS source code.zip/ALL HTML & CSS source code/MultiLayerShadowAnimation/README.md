## Multi-layer shadow animation
![Project thumbnail](./thumbnail.jpg)