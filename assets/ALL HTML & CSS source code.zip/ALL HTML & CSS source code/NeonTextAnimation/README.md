## Neon text animation
![Project thumbnail](./thumbnail.jpg)