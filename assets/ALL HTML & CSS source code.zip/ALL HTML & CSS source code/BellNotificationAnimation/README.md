## Bell notification animation
![Project thumbnail](./thumbnail.jpg)