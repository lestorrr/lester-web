## The CSS grid-template-areas property
![Project thumbnail](./thumbnail.png)