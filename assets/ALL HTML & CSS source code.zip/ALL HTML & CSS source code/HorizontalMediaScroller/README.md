## Horizontal media scroller
![Project thumbnail](./thumbnail.png)