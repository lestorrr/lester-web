## Circular progress bar animation
![Project thumbnail](./thumbnail.png)