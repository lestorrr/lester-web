## Instagram notification animation
![Project thumbnail](./thumbnail.png)
