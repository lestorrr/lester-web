## Card content reveal animation
![Project thumbnail](./thumbnail.png)