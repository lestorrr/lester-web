## Input field animation
![Project thumbnail](./thumbnail.png)