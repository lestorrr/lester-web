## Button toggle animation
![Project thumbnail](./thumbnail.jpg)