## Floating element animation
![Project thumbnail](./thumbnail.jpg)